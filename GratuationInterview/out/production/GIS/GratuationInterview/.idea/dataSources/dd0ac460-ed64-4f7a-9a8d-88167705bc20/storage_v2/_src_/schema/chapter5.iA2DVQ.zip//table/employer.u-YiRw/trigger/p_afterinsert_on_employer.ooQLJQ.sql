create trigger p_afterinsert_on_employer
  after INSERT
  on employer
  for each row
  BEGIN
 if new.Eage<18 or new.Eage>60 then
		signal SQLSTATE 'HY000' set message_text = 'age is out of range';
 end if;
end;

